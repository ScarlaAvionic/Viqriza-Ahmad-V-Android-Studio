package com.thomaskioko.livedatademo.di;

/**
 * Marks an activity / fragment injectable.
 *
 */

public interface Injectable {
}
